playSource("seagirl")

setMusicPitch(0.2);

showDialog("You:*Hello? Can you hear me?@...@ @She seems to explore a much deeper level than this.@...@@As you stare into everchanging pattern on her body, you start to lose yourself in it...@$cmd playSource(\"static_2\")@$cmd setMusicPitch(0.1)@And you just let it happen.@$cmd loadMap(\"pike\",{fade={color=0x000000,time=9000}})")
