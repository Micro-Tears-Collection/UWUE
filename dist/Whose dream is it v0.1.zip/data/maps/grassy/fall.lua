fade(false, function () setMusicPitch(0.7); objVar("player", "pos", {-2430, -270, -5940}); fade(true, nil) end)

objVar("mistress", "pos", {-2547,-270,-6090})
objVar("mistress", "rotY", 190)
grassyFall=true